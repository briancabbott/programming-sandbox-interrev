//
//  Author: Amazon Web Services Inc.
//  August 2013
//

//
// Various CloudFormation statuses for the view filters:
//
var status_active = [ 'CREATE_IN_PROGRESS', 'CREATE_COMPLETE', 'ROLLBACK_COMPLETE'];
var status_complete = [ 'CREATE_COMPLETE', 'UPDATE_COMPLETE', 'UPDATE_ROLLBACK_COMPLETE' ];
var status_failed = [ '_FAILED', 'ROLLBACK_COMPLETE', 'UPDATE_ROLLBACK_COMPLETE' ];
var status_deleted = [ 'DELETE_COMPLETE' ];
var status_in_progress = [ '_IN_PROGRESS' ];

var ew_CFStacksTreeView = {
    model: "cfstacks",
    properties: ["status"],

    activate: function() {
        TreeView.activate.call(this);
    },

    menuChanged: function() {
        var item = this.getSelected();
        $('ew.cfstacks.update').disabled = (item == null);
        $('ew.cfstacks.delete').disabled = (item == null);
        $('ew.cfstacks.info').disabled = (item == null);
    },

    selectionChanged: function() {
        var stack = this.getSelected();

        if (stack) {
            $('ew.cfstacks.outputs.caption').label = "Stack: " + stack.name;
            ew_CFOutputsTreeView.update();
            ew_CFResourcesTreeView.update();
            ew_CFEventsTreeView.update();
            ew_CFTemplateView.update();
        }
    },

    stackCreate: function() {
        var me = this;
        var rc = {ok:null};
        window.openDialog("chrome://ew/content/dialogs/create_cfstack.xul", null, "chrome,centerscreen,modal,resizable", this.core, rc);
        if (rc.ok) {
            me.refresh();
        }
     },

    stackUpdate: function() {
         alert('This feature is not yet available in ElasticWolf'); // TODO: remedy
    },

    stackDelete: function() {
        var me = this;
        var stack = this.getSelected();
        if (stack && confirm('Delete stack ' + stack.name + '?')) {
            this.core.api.deleteCFStack(stack.name, function() { me.refresh(); });
        }
    },

    refreshChildren: function() {
         ew_CFOutputsTreeView.refresh();
         ew_CFResourcesTreeView.refresh();
         ew_CFEventsTreeView.refresh();
         ew_CFTemplateView.refresh();
         ew_CFParametersTreeView.refresh();
         ew_CFTagsView.refresh();
    },

    validateTemplate: function() {
        var me = this;

        function onaccept() {
            var dialog = this;
            var inputs = this.rc.items;
            var values = this.rc.values;

            if (!values[1] && !values[2]) {
                alert("Please choose a local file or enter the URL of a template stored in S3.");
                return true;
            } else if (values[1] && values[2]) {
                alert("Please either choose a local file or enter the\nURL of a template stored in S3, but not both.");
                return true;
            } else {
                return false;
            }
        }

        var values = me.core.promptInput('Validate CloudFormation Template',
                                         [{label:"CloudFormation Template", help:"Please select a local file or enter the URL of a template stored in S3.", type:"section"},
                                          {label:"File Name:", type:"file", size:50, required:0},
                                          {label:"S3 Template URL:", size:50, required:0}],
                                          {onaccept:onaccept});
        if (!values) {
            return;
        } else {
            var params = [[ ]];
            if (values[1]) {
                var body = FileIO.toString(values[1]);
                if (body != '') {
                    params = [[ 'TemplateBody', body ]];
                } else {
                    this.core.errorDialog("Error: could not read file " + values[1]);
                    return;
                }
            } else if (values[2]) {
                params = [[ 'TemplateURL', values[2] ]];
            }

            // Synchronous call
            this.core.api.validateCFTemplate(params, true, function(result) {
                if (result.description && result.description != '') {
                    alert('Template validation was successful.\n\nTemplate description: ' + result.description);
                } else {
                    alert('Template validation was successful.');
                }
            });
        }
    },

    filter: function(list) {
        if (!list) return list;

        var nlist = [];
        var type = $("ew.cfstacks.view.filter").value;
        debug("CF stacks filter: " + type);

        for (var ii = 0; ii < list.length; ii++) {
            var stack = list[ii];

            // Active is every status that is not DELETE_COMPLETE
            if (type == "cf_stacks_active") {
                if (status_deleted.indexOf(stack.status) < 0) {
                    nlist.push(list[ii]);
                }
            } else if (type == "cf_stacks_complete") {
                if (status_complete.indexOf(stack.status) >= 0) {
                    nlist.push(list[ii]);
                }
            } else if (type == "cf_stacks_failed") {
                //debug("Status: " + stack.name + ": " + stack.status);
                if (status_failed.indexOf(stack.status) >= 0) {
                    nlist.push(list[ii]);
                }
            } else if (type == "cf_stacks_deleted") {
                if (status_deleted.indexOf(stack.status) >= 0) {
                    nlist.push(list[ii]);
                }
            } else if (type == "cf_stacks_in_progress") {
                if (status_in_progress.indexOf(stack.status) >= 0) {
                    nlist.push(list[ii]);
                }
            // Else the filter is 'All' so include all stacks
            } else {
                nlist.push(list[ii]);
            }
        }

        $("ew.cfstacks.view.count").value = '' + nlist.length + '/' + list.length;
        list = nlist;
        return TreeView.filter.call(this, list);
    },

    // Allows user to filter on stack status: Active, Complete, Failed, Deleted, in Progress, All
    filterChanged: function() {
        $(this.searchElement).value = "";
        ew_CFOutputsTreeView.display([]);
        ew_CFResourcesTreeView.display([]);
        ew_CFEventsTreeView.display([]);
        ew_CFTemplateView.display('');
        ew_CFParametersTreeView.display([]);
        ew_CFTagsTreeView.display([]);
        this.invalidate();
    },
};

var ew_CFParametersTreeView = {
    name: "cfparameters",
};

var ew_CFTagsTreeView = {
    name: "cftags",
};

var ew_CFOutputsTreeView = {
    name: "cfoutputs",

    refresh: function()
    {
        var stack = ew_CFStacksTreeView.getSelected();
        if (stack) {
            stack.outputs = null;
            stack.parameters = null;
            stack.tags = null;
            this.update();
        }
    },

    update: function()
    {
        var me = this;
        var stack = ew_CFStacksTreeView.getSelected();
        if (!stack) {
            ew_CFParametersTreeView.display([]);
            ew_CFTagsTreeView.display([]);
            this.display([]);
            return;
        }

        this.display(stack.outputs || []);
        ew_CFParametersTreeView.display(stack.parameters || []);
        ew_CFTagsTreeView.display(stack.tags || []);

        if (!stack.outputs) {
            this.core.api.describeCFStacks(stack.id, function(stack) {
                stack.outputs = stack.outputs;
                stack.parameters = stack.parameters;
                stack.tags = stack.tags;
                me.display(stack.outputs);
                ew_CFParametersTreeView.display(stack.parameters);
                ew_CFTagsTreeView.display(stack.tags);
            });
        }
    },
};

var ew_CFEventsTreeView = {
    name: "cfevents",

    refresh: function()
    {
        var stack = ew_CFStacksTreeView.getSelected();
        if (stack) {
            stack.events = null;
            this.update();
        }
    },

    update: function()
    {
        var me = this;
        var stack = ew_CFStacksTreeView.getSelected();
        if (!stack) return this.display([]);

        this.display(stack.events || []);

        if (!stack.events) {
            this.core.api.describeCFStackEvents(stack.id, function(list) {
                stack.events = list;
                me.display(stack.events);
            });
        }
    },
};

var ew_CFResourcesTreeView = {
    name: "cfresources",

    refresh: function()
    {
        var stack = ew_CFStacksTreeView.getSelected();
        if (stack) {
            stack.resources = null;
            this.update();
        }
    },

    update: function()
    {
        var me = this;
        var stack = ew_CFStacksTreeView.getSelected();
        if (!stack) return this.display([]);

        this.display(stack.resources || []);

        if (!stack.resources) {
            this.core.api.describeCFStackResources(stack.id, function(list) {
                stack.resources = list;
                me.display(stack.resources);
            });
        }
    },
};

var ew_CFTemplateView = {
    name: "cftemplate",

    refresh: function()
    {
        var stack = ew_CFStacksTreeView.getSelected();
        if (stack) {
            stack.template = '';
            this.update();
        }
    },

    display: function(template)
    {
        $('ew.cftemplate.view').value = template;
    },

    update: function()
    {
        var me = this;
        var stack = ew_CFStacksTreeView.getSelected();
        if (!stack) return this.display('');

        this.display(stack.template ? JSON.stringify(JSON.parse(template), null, 4) : '');

        if (!stack.template) {
            this.core.api.getCFTemplate(stack.id, function(template) {
                stack.template = template;
                me.display(JSON.stringify(JSON.parse(template), null, 4));
            });
        }
    },
};


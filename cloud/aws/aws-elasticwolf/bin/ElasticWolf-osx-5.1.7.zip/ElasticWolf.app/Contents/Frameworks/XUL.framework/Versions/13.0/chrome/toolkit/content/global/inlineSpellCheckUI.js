Components.utils.import("resource://gre/modules/InlineSpellChecker.jsm");

var InlineSpellCheckerUI = new InlineSpellChecker();
